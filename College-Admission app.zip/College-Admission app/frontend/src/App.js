import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import AddStudent from './components/AddStudent';
import StudentList from './components/StudentList';
import UpdateStudent from './components/UpdateStudent';
import { Container, Navbar, Nav } from 'react-bootstrap';


const App = () => {
  return (
    <Router>
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand href="/">College Admission</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/add">Add Student</Nav.Link>
            <Nav.Link href="/list">Student List</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <Container>
        <Switch>
          <Route path="/add" component={AddStudent} />
          <Route path="/list" component={StudentList} />
          <Route path="/update/:id" component={UpdateStudent} />
          <Route path="/" exact component={StudentList} />
        </Switch>
      </Container>
    </Router>
  );
};

export default App;
