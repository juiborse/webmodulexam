import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Form, Button } from 'react-bootstrap';
import { useParams } from 'react-router-dom';

const UpdateStudent = () => {
  const { id } = useParams();
  const [student, setStudent] = useState({
    id: '',
    name: '',
    addr: '',
    stream: '',
    year: '',
  });

  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/students/${id}`);
        setStudent(response.data);
      } catch (error) {
        console.error('Error fetching student:', error);
      }
    };
    fetchStudent();
  }, [id]);

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/api/students/${id}`, student);
      alert('Student updated successfully');
    } catch (error) {
      console.error('Error updating student:', error);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      {/* Form fields for student details */}
      <Button type="submit">Update Student</Button>
    </Form>
  );
};

export default UpdateStudent;
