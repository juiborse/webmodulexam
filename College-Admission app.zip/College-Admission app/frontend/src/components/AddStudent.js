import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button } from 'react-bootstrap';

const AddStudent = () => {
  const [student, setStudent] = useState({
    id: '',
    name: '',
    addr: '',
    stream: '',
    year: '',
  });

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/students', student);
      alert('Student added successfully');
    } catch (error) {
      console.error('Error adding student:', error);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      {/* Form fields for student details */}
      <Button type="submit">Add Student</Button>
    </Form>
  );
};

export default AddStudent;
