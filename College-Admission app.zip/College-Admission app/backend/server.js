import express from 'express';
import dotenv from 'dotenv';
import connectDB from './config/db.js';
import studentRoutes from './routes/studentRoutes.js';
import cors from 'cors';
const mongoose = require('mongoose');
const express = require('express');


// Load environment variables from .env file
dotenv.config();

// Connect to the MongoDB database
connectDB();

// Initialize Express app
const app = express();

// Middleware to parse JSON requests
app.use(express.json());

// Middleware to handle CORS (Cross-Origin Resource Sharing)
app.use(cors());

// Routes for student operations
app.use('/api/students', studentRoutes);

// Serve the frontend (for production build)
// Uncomment and modify if you have a production build to serve
// import path from 'path';
// const __dirname = path.resolve();
// if (process.env.NODE_ENV === 'production') {
//   app.use(express.static(path.join(__dirname, '/frontend/build')));
//   app.get('*', (req, res) => res.sendFile(path.resolve(__dirname, 'frontend', 'build', 'index.html')));
// }

// Get the port from environment variables or default to 5000
const PORT = process.env.PORT || 5000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  mongoose.set('strictQuery', false); // Or true, depending on your application's needs

});


