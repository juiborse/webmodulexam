import express from 'express';
import asyncHandler from 'express-async-handler';
import Student from '../models/studentModel.js';

const router = express.Router();

// @desc    Add a student
// @route   POST /api/students
// @access  Public
router.post('/', asyncHandler(async (req, res) => {
  const { id, name, addr, stream, year } = req.body;
  const student = new Student({ id, name, addr, stream, year });
  const createdStudent = await student.save();
  res.status(201).json(createdStudent);
}));

// @desc    Get all students
// @route   GET /api/students
// @access  Public
router.get('/', asyncHandler(async (req, res) => {
  const students = await Student.find({});
  res.json(students);
}));

// @desc    Get student by ID
// @route   GET /api/students/:id
// @access  Public
router.get('/:id', asyncHandler(async (req, res) => {
  const student = await Student.findById(req.params.id);
  if (student) {
    res.json(student);
  } else {
    res.status(404).json({ message: 'Student not found' });
  }
}));

// @desc    Update a student
// @route   PUT /api/students/:id
// @access  Public
router.put('/:id', asyncHandler(async (req, res) => {
  const { id, name, addr, stream, year } = req.body;
  const student = await Student.findById(req.params.id);

  if (student) {
    student.id = id;
    student.name = name;
    student.addr = addr;
    student.stream = stream;
    student.year = year;

    const updatedStudent = await student.save();
    res.json(updatedStudent);
  } else {
    res.status(404).json({ message: 'Student not found' });
  }
}));

export default router;
