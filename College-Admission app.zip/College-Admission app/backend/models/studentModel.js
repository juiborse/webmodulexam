import mongoose from 'mongoose';

const studentSchema = mongoose.Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  addr: { type: String, required: true },
  stream: { type: String, required: true },
  year: { type: String, required: true },
}, {
  timestamps: true,
});

const Student = mongoose.model('Student', studentSchema);

export default Student;
